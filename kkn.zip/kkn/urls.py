
from django.contrib import admin
from django.urls import path,include
from investarisasi.models import Investarisasi,Sawah,Kebun
from djgeojson.views import GeoJSONLayerView

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home),
    path('investarisasi/',include('investarisasi.urls', namespace='investarisasi')),
  
]
