
from django.urls import path
from . import views
from djgeojson.views import GeoJSONLayerView
from .models import Investarisasi,Sawah,Kebun,SemakBelukar,Hutan,LahanKosong,Tambak

app_name='peta'

urlpatterns = [
    path('',views.peta,name='index'),
    path('dataSawah', GeoJSONLayerView.as_view(model=Sawah,properties=('luas', 'pemilik','jenis')), name='dataSawah'),
    path('dataKebun', GeoJSONLayerView.as_view(model=Kebun,properties=('luas', 'pemilik','jenis')), name='dataKebun'),
    path('dataHutan', GeoJSONLayerView.as_view(model=Hutan,properties=('luas', 'pemilik','jenis')), name='dataHutan'),
    path('dataLahanKosong', GeoJSONLayerView.as_view(model=LahanKosong,properties=('luas', 'pemilik','jenis')), name='dataLahanKosong'),
    path('dataTambak', GeoJSONLayerView.as_view(model=Tambak,properties=('luas', 'pemilik','jenis')), name='dataTambak'),
    path('dataSemakBelukar', GeoJSONLayerView.as_view(model=SemakBelukar,properties=('luas', 'pemilik','jenis')), name='dataSemakBelukar'),
]
